package edu.cmu.manfred.types;

//GameState are enums representing the SUCCESS or FAILED status when running a new game
public class GameState {
	public static int SUCCESS = 1;
	public static int FAILED = 0;
}
